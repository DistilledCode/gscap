import numpy as np
import pandas as pd
from scipy.optimize import minimize 


def volatility_scalar(price_df, return_callable, ticker, daily_cash_volatility_target, halflife=11):
    temp = pd.DataFrame()
    temp["daily_returns"] = return_callable(price_df) #*100
    temp["daily_returns"] = temp["daily_returns"].fillna(0)

    temp["daily_volatility"] = temp["daily_returns"].ewm(halflife = halflife).std()

    temp["block_value"] = (price_df.underlying[ticker.symbol] * ticker.currency_multiplier) #/ 100
    temp["instrument_currency_volatility"] = temp["daily_volatility"] * temp["block_value"]

    temp["volatility_scalar"] = daily_cash_volatility_target / temp["instrument_currency_volatility"]
    temp["volatility_scalar"] = temp["volatility_scalar"].shift(1)

    return temp[["volatility_scalar"]].squeeze()

def correlation(returns):
    return returns.corr().clip(lower=0)

def sharpe_ratio(weights, returns):
    portfolio_return = np.sum(returns.mean() * weights) * 252  # Annualized
    portfolio_volatility = np.sqrt(np.dot(weights.T, np.dot(returns.cov() * 252, weights)))
    return -portfolio_return / portfolio_volatility  # Negative for minimization

def optimize_portfolio(sample_returns):

    n_assets = sample_returns.shape[1]
    init_weights = np.ones(n_assets) / n_assets
    bounds = [(0, 1) for _ in range(n_assets)]
    constraints = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1})

    result = minimize(sharpe_ratio, init_weights, args=(sample_returns,), bounds=bounds, constraints=constraints)

    return result.x

def bootstrap(returns, n_itr, frac):
    optimized_weights = []
    for _ in range(n_itr):
        sample = returns.sample(frac=frac, replace=True)
        weight = optimize_portfolio(sample)
        optimized_weights.append(weight)

    avg_weights = np.mean(optimized_weights, axis=0)
    final_weights = avg_weights / np.sum(avg_weights)

    # risk scaling 
    volatility = returns.std() * np.sqrt(252)
    risk_scaled_weights = final_weights / volatility
    risk_scaled_weights /= risk_scaled_weights.sum()

    return risk_scaled_weights


def instrument_weight(returns, resample = "YE", n_itr = 100, frac = 0.1):
    # returns = price_df.adjusted.diff() / price_df.underlying.shift(1)
    resample_returns = returns.resample(resample).last()
    
    list_weights =[]
    for timestamp in resample_returns.index:
        weights = bootstrap(returns.loc[:timestamp], n_itr, frac)
        weights.name = timestamp
        list_weights.append(weights)

    df  = pd.concat(list_weights, axis=1).T
    df = df.fillna(0)
    temp_index = df.index.union(returns.index)
    df = df.reindex(temp_index).bfill().ffill().reindex(returns.index)

    return df


def _IDM(returns, weights):
    W = weights
    H = correlation(returns)

    if np.allclose(H, 0):
        return np.nan

    idm = 1 / np.sqrt(W.T @ H @ W)
    return idm


def IDM(returns, weights, resample="W"):
    # returns = price_df.adjusted.diff() / price_df.underlying.shift(1)
    resample_returns = returns.resample(resample).last()
    
    resample_returns["idm"] = None 
    for timestamp in resample_returns.index:
        # timestamp of weight can be included?
        resample_returns.loc[timestamp, "idm"] = _IDM(returns.loc[:timestamp], weights.loc[:timestamp].iloc[-1])
    
    df = resample_returns["idm"].to_frame()
    temp_index = df.index.union(returns.index)
    df = df.reindex(temp_index).bfill().ffill().reindex(returns.index)

    return df